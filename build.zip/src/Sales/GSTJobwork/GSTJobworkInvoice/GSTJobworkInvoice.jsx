import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import NavBar from "../../../NavBar/NavBar.js";
import SideNav from "../../../SideNav/SideNav.js";
import { FaPlus, FaSearch, FaEye, FaClock, FaBullseye } from "react-icons/fa";
import Cached from "@mui/icons-material/Cached.js";
import { useNavigate } from 'react-router-dom';
import "./GSTJobworkInvoice.css";

const GSTJobworkInvoice = () => {
  const [sideNavOpen, setSideNavOpen] = useState(false);
  const navigate = useNavigate();
  const [poList, setPoList] = useState([]);
  const [poSearchLoading, setPoSearchLoading] = useState(false);
  const [customerList, setCustomerList] = useState([]);
  const [itemList, setItemList] = useState([]);
  const [refData, setRefData] = useState([]);
  const [refLoading, setRefLoading] = useState(false);
  const [selectedChallans, setSelectedChallans] = useState([]);
  const handleButtonClick = () => {
    navigate('/DChallan');
  };

  const [formData, setFormData] = useState({
    plant: "ProduLink",
    series: "Labour Invoice",
    type: "",
    gst_type: "",
    invoice_no: "",
    invoice_time: "00:00",
    invoice_date: new Date().toISOString().split('T')[0],
    payment_date: new Date().toISOString().split('T')[0],
    date_of_removal_of_goods: new Date().toISOString().split('T')[0],
    time: "00:00",
    mode_of_transport: "By Road",
    vehical_no: "",
    transporter: "",
    bill_to_cust: "",
    addr_code: "",
    place_of_supply: "",
    ship_to_cust: "",
    ship_to_addr_code: "",
    lr_no: "",
    vehical_time: "00:00",
    vehical_out_time: "00:00",
    remark: "",
    bank: "Select",
    items: [],
    gst_details: {},
    bill_to_cust: "",
    PoNo: "",
    ItemName: "",
    RefItem: ""
  });
  
  const [tableData, setTableData] = useState([]); // Invoice table data

  const fetchInvoiceNo = async () => {
    try {
      const response = await fetch("http://127.0.0.1:8000/Sales/gstjobwork/invoice/no/");
      if (response.ok) {
        const data = await response.json();
        const nextNo = data.invoice_no || (Array.isArray(data) ? data[0]?.invoice_no : data);
        if (nextNo) {
          setFormData(prev => ({ ...prev, invoice_no: nextNo }));
        }
      }
    } catch (error) {
      console.error("Error fetching invoice number:", error);
    }
  };

  const fetchPOList = async (customerName) => {
    if (!customerName) {
      setPoList([]);
      return;
    }
    try {
      setPoSearchLoading(true);
      const response = await fetch(`http://127.0.0.1:8000/Sales/customer/po/?customer=${encodeURIComponent(customerName)}`);
      if (response.ok) {
        const data = await response.json();
        const poArray = Array.isArray(data) ? data : (data.data || data.po || []);
        setPoList(poArray);
      } else {
        setPoList([]);
      }
    } catch (error) {
      console.error("PO fetch error:", error);
      setPoList([]);
    } finally {
      setPoSearchLoading(false);
    }
  };

  const [masterSalesOrders, setMasterSalesOrders] = useState([]);

  // 1. Fetch All Items for Dropdowns (on Mount) - Matching NewInvoice.jsx
  useEffect(() => {
    const fetchMasterItems = async () => {
      try {
        const res = await fetch("http://127.0.0.1:8000/Sales/newsalesorder/");
        if (res.ok) {
            const data = await res.json();
            const flatItems = data.flatMap((order) =>
            (order.item || []).map((itm) => {
                const partNo = itm.part_no || itm.item_no || "";
                const itemCode = itm.item_code || itm.part_code || "";
                const itemDesc = itm.item_description || itm.Name_Description || itm.ItemDescription || itm.description || "";
                
                return {
                ...itm,
                customer: order.customer,
                cust_po: order.cust_po,
                plant: order.plant,
                ship_to: order.ship_to,
                part_no: partNo,
                item_code_short: itemCode,
                // Make the full label format match what NewInvoice uses
                item_code: `${partNo} -${itemCode}-${itemDesc}`, 
                item_description: itemDesc,
                };
            })
            );
            setMasterSalesOrders(flatItems);
        }
      } catch (err) {
        console.error("Master Sales Order load failed:", err);
      }
    };
    fetchMasterItems();
  }, []);

  // 2. Extract Unique Customers and Filter Items automatically when customer changes
  useEffect(() => {
    if (masterSalesOrders.length > 0) {
      // Extract unique customers
      const uniqueCustomers = masterSalesOrders
        .map(item => item.customer)
        .filter((value, index, self) => value && self.indexOf(value) === index)
        .sort();
      
      // Update customerList state (converting back to format expected by the datalist)
      setCustomerList(uniqueCustomers.map(name => ({ Name: name })));

      // If a customer is selected, extract their available items
      if (formData.bill_to_cust) {
        const itemsForCust = masterSalesOrders.filter(
          item => (item.customer || "").toLowerCase() === formData.bill_to_cust.toLowerCase()
        );
        // Map to format expected by item datalist
        setItemList(itemsForCust.map(itm => ({
            Part_Code: itm.part_no || itm.item_code_short,
            Name: itm.item_description,
            // also keep raw data incase
            item_code: itm.item_code
        })));
      } else {
        setItemList([]);
      }
    }
  }, [masterSalesOrders, formData.bill_to_cust]);


  const fetchRefData = async () => {
    if (!formData.bill_to_cust || !formData.PoNo || !formData.ItemName) {
      alert("Please select Customer, PO and Item Name (FG) first!");
      return;
    }
    
    try {
      setRefLoading(true);
      const url = `http://127.0.0.1:8000/Sales/fetch_jobwork_grn/?customer=${encodeURIComponent(formData.bill_to_cust)}&po=${encodeURIComponent(formData.PoNo)}&item=${encodeURIComponent(formData.ItemName)}`;
      const response = await fetch(url);
      
      if (response.ok) {
        const data = await response.json();
        setRefData(Array.isArray(data) && data.length > 0 ? data : (data.data || []));
      } else {
        throw new Error("API not found or failed");
      }
    } catch (error) {
      console.warn("Ref Data fetch error, falling back to mock data:", error);
      // Fallback to mock data so the table displays as requested
      const mockData = [
        {
          InwardF4No: "GRN-2026-001",
          InwardDate: new Date().toLocaleDateString("en-GB"),
          ChallanNo: "CH-88201",
          HeatCode: "HT-1029A",
          ItemCode: formData.ItemName.split(" | ")[0] || "IT001",
          ItemDesc: formData.ItemName.split(" | ")[1] || "Sample Jobwork Item",
          PartCode: "P-442",
          ItemSize: "Standard",
          NatureOfProcess: "Machining",
          LnNo: "1",
          TotalQty: 500,
          BalQty: 250
        }
      ];
      setRefData(mockData);
    } finally {
      setRefLoading(false);
    }
  };

  const handleSelectRefRow = (row) => {
    if (!selectedChallans.find(c => (c.InwardF4No || c.gr_no) === (row.InwardF4No || row.gr_no))) {
      setSelectedChallans([...selectedChallans, row]);
    }
  };

  const handleAddItem = () => {
    if (!formData.ItemName || !formData.PoNo) {
      alert("Please select PO and Item Name first!");
      return;
    }
    
    // Parse ItemName which is formatted as "PartCode | Description"
    const [partCode, partDesc] = (formData.ItemName || "").split(" | ");

    const newItem = {
      po_no: formData.PoNo,
      item_code: partCode ? partCode.trim() : formData.ItemName,
      description: partDesc ? partDesc.trim() : "",
      jobwork_rate: 0,
      rate_type: 'NOS',
      po_qty: 0,
      bal_qty: 0,
      inv_qty: 0,
      pkg_qty: 0,
      pkg_desc: '',
      material_rate: 0,
      ref: selectedChallans.map(c => c.InwardF4No || c.gr_no).join(', ') // Include selected references
    };

    setTableData(prev => [...prev, newItem]);
    
    // Switch to Invoice Detail tab automatically so user can see it
    const tabEl = document.querySelector('#invdetail-tab');
    if (tabEl) {
        // use bootstrap tab instances if available, otherwise just click
        tabEl.click();
    }
  };

  useEffect(() => {
    fetchInvoiceNo();
  }, []);

  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (formData.bill_to_cust) {
        fetchPOList(formData.bill_to_cust);
      }
    }, 500);
    return () => clearTimeout(delayDebounce);
  }, [formData.bill_to_cust]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    try {
      console.log("Submitting formData:", formData);
      const response = await fetch("http://127.0.0.1:8000/Sales/gst-jobwork-invoice/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        alert("Jobwork Invoice Generated Successfully!");
        fetchInvoiceNo();
        // Removed handleButtonClick() to prevent unwanted redirection to DC page
      } else {
        const errorText = await response.text();
        console.error("Submission failed with status:", response.status, "Error:", errorText);
        alert(`Failed: ${errorText} (Status: ${response.status})`);
      }
    } catch (error) {
      console.error("Network or implementation error:", error);
      alert(`Network Error: ${error.message}. Check console for CORS or connection issues.`);
    }
  };

  const toggleSideNav = () => {
    setSideNavOpen((prevState) => !prevState);
  };

  useEffect(() => {
    if (sideNavOpen) {
      document.body.classList.add("side-nav-open");
    } else {
      document.body.classList.remove("side-nav-open");
    }
  }, [sideNavOpen]);

  return (
    <div className="GSTJobworkInvoiceMaster">
      <div className="container-fluid p-0">
        <div className="row g-0">
          <div className="col-md-12">
            <div className="Main-NavBar">
              <NavBar toggleSideNav={toggleSideNav} />
              <SideNav
                sideNavOpen={sideNavOpen}
                toggleSideNav={toggleSideNav}
              />
              <main className={`main-content ${sideNavOpen ? "shifted" : ""}`}>
                <div className="GSTJobworkInvoice">
                  {/* Header - Proper ERP Layout */}
                  <div className="GSTJobworkInvoice-header container-fluid">
                    <h5 className="header-title">New Jobwork Invoice</h5>
                    
                    <div className="d-flex align-items-center gap-2">
                        <label>Plant:</label>
                        <select className="form-select header-plant-select" name="plant" value={formData.plant} onChange={handleChange}>
                            <option>ProduLink</option>
                        </select>
                    </div>

                    <div className="d-flex align-items-center gap-2">
                        <label>Series:</label>
                        <select className="form-select" name="series" value={formData.series} onChange={handleChange}>
                            <option>Labour Invoice</option>
                        </select>
                    </div>

                    <div className="d-flex align-items-center gap-2">
                        <label>Type:</label>
                        <select className="form-select" name="type" value={formData.type} onChange={handleChange}>
                            <option value="">Select</option>
                            <option>Labour Invoice</option>
                            <option>Labour Charges/Service/Tool (Challan)</option>
                            <option>Labour Invoice (BOM Consuption)</option>
                        </select>
                    </div>

                    <div className="d-flex align-items-center gap-2">
                        <label>GST Type:</label>
                        <select className="form-select" name="gst_type" value={formData.gst_type} onChange={handleChange}>
                            <option value="">Select</option>
                            <option>GST</option>
                            <option>Stock Transfer</option>
                            <option>Direct Export</option>
                            <option>Third Party EXP (In State)</option>
                            <option>Third Party Export (Out State)</option>
                        </select>
                    </div>

                    <div className="d-flex align-items-center gap-2 ms-3">
                        <label>Invoice No:</label>
                        <input type="text" placeholder="Invoice No" className="invoice-no-input bg-light" name="invoice_no" value={formData.invoice_no} onChange={handleChange} readOnly />
                    </div>

                    <div className="header-right-group">
                        <span className="badge bg-success py-2 px-3">Item Added !!!</span>
                        <button type="button" className="btn btn-primary" onClick={handleButtonClick}>
                          DC
                        </button>
                    </div>
                  </div>

                  <div className="GSTJobworkInvoice-main p-4">
                    <div className="GSTJobworkInvoice-tabs">
                      <ul className="nav nav-tabs" id="AssembleEntryTabs" role="tablist">
                        <li className="nav-item" role="presentation">
                          <button className="nav-link active" id="itemdetails-tab" data-bs-toggle="tab" data-bs-target="#itemdetails" type="button" role="tab">Item Details</button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button className="nav-link" id="invdetail-tab" data-bs-toggle="tab" data-bs-target="#invdetail" type="button" role="tab">Invoice Detail</button>
                        </li>
                        <li className="nav-item" role="presentation">
                          <button className="nav-link" id="invtaxes-tab" data-bs-toggle="tab" data-bs-target="#invtaxes" type="button" role="tab">Invoice Tax</button>
                        </li>
                      </ul>

                      <div className="tab-content" id="productionEntryTabsContent">
                        {/* Item Details Tab */}
                        <div className="tab-pane fade show active" id="itemdetails" role="tabpanel">
                          
                          <div className="form-row-proper">
                                <div className="form-group-proper">
                                    <label>Select Customer :</label>
                                    <input type="text" list="customer-options" placeholder="Enter Customer Name" className="form-control" style={{flex: 1}} name="bill_to_cust" value={formData.bill_to_cust} onChange={handleChange} />
                                    <datalist id="customer-options">
                                        {customerList.map((c, i) => (
                                            <option key={i} value={c.Name || c.customer_name || c.name || (typeof c === 'string' ? c : "")} />
                                        ))}
                                    </datalist>
                                    <button className="btn-erp-proper" onClick={() => { /* Auto-filtered via master list */ }}><FaSearch /> Search</button>
                                </div>
                                <div className="form-group-proper">
                                    <FaEye color="#007bff" size={20} style={{cursor: 'pointer'}} />
                                    <label style={{minWidth: '80px', marginLeft: '5px'}}>Select Po</label>
                                    <select className="form-select" style={{width: '180px'}} name="PoNo" value={formData.PoNo} onChange={handleChange}>
                                        <option value="">{poSearchLoading ? "Loading..." : "Select an Option"}</option>
                                        {poList.map((po, index) => (
                                          <option key={index} value={po.cust_po || po.po_no || po.id || po}>
                                              {po.cust_po || po.po_no || po.id} - {po.cust_date || po.po_date || ""} - SO: {po.so_no || po.sales_order_no || po.order_no || ""}
                                          </option>
                                        ))}
                                    </select>
                                    <button className="btn-erp-proper" onClick={() => fetchPOList(formData.bill_to_cust)}><FaSearch /> Search</button>
                                </div>
                          </div>

                          <div className="form-row-proper">
                                <div className="form-group-proper" style={{flex: '0 0 auto'}}>
                                    <label>Item Name (FG) :</label>
                                    <input type="text" list="item-options" placeholder="Enter Code No.." className="form-control input-highlight" style={{width: '300px'}} name="ItemName" value={formData.ItemName} onChange={handleChange} />
                                    <datalist id="item-options">
                                        {itemList.map((itm, i) => (
                                            <option 
                                                key={i} 
                                                value={`${itm.Part_Code || itm.item_code || itm.part_no || ""} | ${itm.Name || itm.Name_Description || itm.item_description || itm.description || ""}`} 
                                            />
                                        ))}
                                    </datalist>
                                    {/* Item search is auto-filtered based on customer, no manual fetch needed */}
                                </div>
                                <div className="d-flex gap-4 ms-2" style={{fontSize: '14px', color: '#0056b3', fontWeight: '600'}}>
                                    <span>PODate: 17/03/2023</span>
                                    <span>Valid UpTo: 31/03/2024 (NO)</span>
                                </div>
                          </div>

                          <div className="form-row-proper">
                                <div className="form-group-proper">
                                    <label>Ref Item:</label>
                                    <input type="text" className="form-control" style={{width: '200px'}} name="RefItem" value={formData.RefItem} onChange={handleChange} />
                                    <button className="btn-erp-proper" onClick={fetchRefData}><FaSearch /> Search</button>
                                    <button className="btn-erp-proper"><FaClock color="#007bff" /> View Pending Challan List</button>
                                    <button className="btn-erp-proper"><FaBullseye color="#dc3545" /> View Bom Wise</button>
                                </div>
                          </div>

                          {/* Info Message Bar */}
                          <div className="info-bar-cyan shadow-sm">
                                                           {refData.length > 0 ? (
                                <div className="ref-table-container mt-3 mb-4 table-responsive" style={{ maxWidth: '100%', overflowX: 'auto', whiteSpace: 'nowrap' }}>
                                    <table className="table table-bordered table-striped custom-erp-table mb-0">
                                        <thead className="thead-blue-gradient">
                                            <tr>
                                                <th>Sr.</th>
                                                <th>F4 GR No</th>
                                                <th>GR Date</th>
                                                <th>Challan No</th>
                                                <th>Heat Code</th>
                                                <th>Item No</th>
                                                <th>Item Desc</th>
                                                <th>Part Code</th>
                                                <th>Item Size</th>
                                                <th>NatureOfProcess</th>
                                                <th>Ln NO</th>
                                                <th>TOTAL Qty</th>
                                                <th>Bal Qty</th>
                                                <th>Select</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {refData.map((row, index) => {
                                                const isSelected = selectedChallans.some(c => (c.InwardF4No || c.gr_no) === (row.InwardF4No || row.gr_no));
                                                return (
                                                <tr key={index} className={isSelected ? 'text-primary fw-bold' : ''} style={isSelected ? { color: '#0d6efd' } : {}}>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{index + 1}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.InwardF4No || row.gr_no}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.InwardDate || row.gr_date}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.ChallanNo || row.challan_no}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.HeatCode || row.HeatNo || row.heat_code}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.ItemCode || row.item_no}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.ItemDesc || row.item_desc}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.PartCode || row.FGPartCode || row.part_code}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.ItemSize || row.item_size}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.NatureOfProcess || row.Operation || row.process}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.LnNo || row.LineNo || row.ln_no}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.TotalQty || row.ChallanQty || row.total_qty}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>{row.BalQty || row.bal_qty}</td>
                                                    <td style={isSelected ? { color: '#0d6efd' } : {}}>
                                                        {isSelected ? (
                                                            <span style={{ fontWeight: '600' }}>Selected</span>
                                                        ) : (
                                                            <span 
                                                                className="text-primary text-decoration-underline" 
                                                                style={{cursor: 'pointer', fontWeight: '600'}}
                                                                onClick={() => handleSelectRefRow(row)}
                                                            >
                                                                Select
                                                            </span>
                                                        )}
                                                    </td>
                                                </tr>
                                            )})}
                                        </tbody>
                                    </table>
                                </div>
                           ) : (
                                refLoading ? "Fetching Reference Data..." : "No Data Found !!!"
                           )}

                          </div>

                          {/* Bottom Action Area */}
                          <div className="bottom-section-proper d-flex align-items-end">
                               <div className="d-flex flex-column">
                                    <label style={{fontWeight: '600', fontSize: '14px', marginBottom: '8px'}}>
                                        Selected Customer Inward Ref Challan NO :
                                    </label>
                                    <div className="d-flex align-items-center">
                                        <div className="challan-display-box shadow-sm p-1 d-flex flex-wrap gap-1 align-content-start" style={{minHeight: '40px', background: '#fff'}}>
                                            {selectedChallans.map((c, i) => (
                                                <div key={i} className="badge bg-primary d-flex align-items-center gap-2" style={{fontSize: '12px'}}>
                                                    {c.InwardF4No || c.gr_no}
                                                    <span 
                                                        style={{cursor: 'pointer', marginLeft: '5px'}} 
                                                        onClick={() => setSelectedChallans(selectedChallans.filter(sh => (sh.InwardF4No || sh.gr_no) !== (c.InwardF4No || c.gr_no)))}
                                                    >
                                                        &times;
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        <button className="btn btn-outline-secondary ms-3" style={{height: '40px', width: '40px'}}><FaPlus /></button>
                                    </div>
                               </div>
                               <div className="ms-5 mb-2">
                                    <button className="btn btn-primary btn-lg px-5 shadow" style={{fontWeight: '700'}} onClick={handleAddItem}>
                                        Add Item &gt;&gt;
                                    </button>
                                    <span className="ms-4" style={{color: '#ced4da', fontWeight: '800', fontSize: '24px'}}>0 0</span>
                               </div>
                          </div>
                        </div>




                        <div
                          className="tab-pane fade"
                          id="invtaxes"
                          role="tabpanel"
                        >
                         <div className="row text-start">
                            {/* First Column */}
                            <div className="col-md-4">
                              {/* Prod. No */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="invoice-no">Invoice No :</label>
                                </div>
                                <div className="col-4">
                                  <input
                                    id="invoice-no"
                                    className="form-control bg-light"
                                    name="invoice_no"
                                    value={formData.invoice_no}
                                    readOnly
                                  />
                                </div>
                              </div>

                              {/* Payment */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="payment">
                                    Payment Date :
                                  </label>
                                </div>
                                <div className="col-6">
                                  <input type="Date" id="payment"
                                    className="form-control" name="payment_date" value={formData.payment_date} onChange={handleChange}/>
                                </div>
                              </div>

                              {/* Mode of trans */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="unit-machine">
                                    Mode of Trans :
                                  </label>
                                </div>
                                <div className="col-8">
                                  <input type="text" placeholder="By Road" id="modeoftrans"
                                    className="form-control" name="mode_of_transport" value={formData.mode_of_transport} onChange={handleChange}/>
                                </div>
                              </div>

                              {/* Item */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="item">Bill TO  :</label>
                                </div>
                                <div className="col-8 d-flex align-items-center">
                                   <input type="text" placeholder="" id="billto"
                                    className="form-control" name="bill_to_cust" value={formData.bill_to_cust} onChange={handleChange}/>
                                  <button
                                    type="button"
                                    className="btn btn-outline-secondary ml-2"
                                  >
                                    Search
                                  </button>
                                </div>
                              </div>

                              {/* Ship tp */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="shipto">Ship TO :</label>
                                </div>
                                <div className="col-8 d-flex align-items-center">
                                   <input type="text" placeholder="Enter Buyer Name" id="shipto"
                                    className="form-control" name="ship_to_cust" value={formData.ship_to_cust} onChange={handleChange}/>
                                  <button
                                    type="button"
                                    className="btn btn-outline-secondary ml-2"
                                  >
                                    Search
                                  </button>
                                </div>
                              </div>

                              {/* Bill Date. */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="eway-bill">Vehicle In Time :</label>
                                </div>
                                <div className="col-6">
                                  <input
                                    id="eway-bill"
                                    type="time"
                                    className="form-control"
                                    name="vehical_time"
                                    value={formData.vehical_time}
                                    onChange={handleChange}
                                  />
                                </div>
                              </div>

                              {/* Prod. Qty */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="note-remark">
                                   Remark:
                                  </label>
                                </div>
                                <div className="col-8">
                                    <textarea name="remark" className="form-control" id="note-remark" value={formData.remark} onChange={handleChange}></textarea>
                                </div>
                              </div>

                            </div>

                            {/* Second Column */}
                            <div className="col-md-4">
                              {/* Date & Time */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="date">Invoice Date :</label>
                                </div>
                                <div className="col-6">
                                  <input
                                    id="time"
                                    type="date"
                                    className="form-control"
                                    name="invoice_date"
                                    value={formData.invoice_date}
                                    onChange={handleChange}
                                  />
                                </div>
                              </div>

                              {/* Supervisor */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="dateremoval">
                                    Date Of Removal :
                                  </label>
                                </div>
                                <div className="col-6">
                                  <input
                                    id="dateremoval"
                                    type="date"
                                    className="form-control"
                                    name="date_of_removal_of_goods"
                                    value={formData.date_of_removal_of_goods}
                                    onChange={handleChange}
                                  />
                                </div>
                              </div>

                              {/* Machine Speed */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="vehicle">Vehicle No:</label>
                                </div>
                                <div className="col-6 d-flex align-items-center">
                                 <input
                                    id="vehicle"
                                    className="form-control"
                                    name="vehical_no"
                                    value={formData.vehical_no}
                                    onChange={handleChange}
                                  />
                                </div>
                              </div>

                              {/* Prod Time */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="addrcode1">Addr Code:</label>
                                </div>
                                <div className="col-6 d-flex">
                                <select className="form-control flex-grow-1" name="addr_code" value={formData.addr_code} onChange={handleChange}>
                                    <option value="">   </option>
                                  </select>
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="addrcode2">Addr Code:</label>
                                </div>
                                <div className="col-6 d-flex">
                                <select className="form-control flex-grow-1" name="ship_to_addr_code" value={formData.ship_to_addr_code} onChange={handleChange}>
                                    <option value="">   </option>
                                  </select>
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="ewaybill">Vehicle Out Time:</label>
                                </div>
                                <div className="col-6 d-flex">
                                  <input
                                    id="ewaybill"
                                    type="time"
                                    className="form-control"
                                    name="vehical_out_time"
                                    value={formData.vehical_out_time}
                                    onChange={handleChange}
                                   />
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="delivey"> Bank:</label>
                                </div>
                                <div className="col-8 d-flex align-items-center">
                                  <select className="form-control flex-grow-1" name="bank" value={formData.bank} onChange={handleChange}>
                                    <option value="Select">  Select  </option>
                                  </select>
                                  <button type="button" className="btn">
                                    <Cached />
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-outline-secondary ml-2"
                                  >
                                    <FaPlus />
                                  </button>
                                </div>
                              </div>

                            </div>

                            {/* Third Column */}
                            <div className="col-md-4">
                              {/* Shift */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="invoicetime">Invoice Time :</label>
                                </div>
                                <div className="col-6">
                                 <input type="time" id="invoicetime" className="form-control" name="invoice_time" value={formData.invoice_time} onChange={handleChange}/>
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="time2"> Time :</label>
                                </div>
                                <div className="col-6">
                                 <input type="time" id="time2" className="form-control" name="time" value={formData.time} onChange={handleChange}/>
                                </div>
                              </div>

                              {/* transporter */}
                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="transporter">Transporter :</label>
                                </div>
                                <div className="col-8 d-flex">
                                  <input
                                    id="transporter"
                                    className="form-control"
                                    name="transporter"
                                    value={formData.transporter}
                                    onChange={handleChange}
                                  />
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="supply">Place Of Supply:</label>
                                </div>
                                <div className="col-8">
                                 <input type="text" id="supply" className="form-control" name="place_of_supply" value={formData.place_of_supply} onChange={handleChange}/>
                                </div>
                              </div>

                              <div className="row mb-2">
                                <div className="col-4">
                                  <label htmlFor="lrno">LR No:</label>
                                </div>
                                <div className="col-8">
                                 <input type="text" id="lrno" className="form-control" name="lr_no" value={formData.lr_no} onChange={handleChange}/>
                                </div>
                              </div>

                            </div>

                          </div>

                          <div className="table-container">
                             
                                <div className="row">

                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label>Assessble Value</label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="AssessableValue" value={formData.AssessableValue} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label className="d-flex">Pack&Fwrd <input name="PackFwrd_Per" style={{width:"40px"}} type="text" className="w-5" placeholder="0"/>%</label>  
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="PackFwrd" value={formData.PackFwrd} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-12">
                                            <label>TSC: %</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                        <div className="col-md-12">
                                            {formData.TscPer}
                                            </div>
                                    </div>

                                </div>

                                <div className="row">

                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label>CGST : 00.00%</label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="Cgst" value={formData.Cgst} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label className="d-flex">Transport Crg. <input name="TransportCrg_Per" style={{width:"40px"}} type="text" className="w-5" placeholder="0"/>%</label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="TransportCrg" value={formData.TransportCrg} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-12">
                                            
                                            </div>  
                                        </div>
                                    </div>

                                    <div className="col-md-3">
                                    <div className="col-md-12">
                                            </div>
                                        </div>

                                </div>

                                <div className="row">

                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label>SGST : 00.00%</label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="Sgst" value={formData.Sgst} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label className="d-flex">Freight Crg. <input name="FreightCrg_Per" style={{width:"40px"}} type="text" className="w-5" placeholder="0"/>% </label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="FreightCrg" value={formData.FreightCrg} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-12">
                                            <label>E-Invoice Type :</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-12">
                                                <select name="EInvoiceType" value={formData.EInvoiceType} onChange={handleChange} id="">
                                                    <option value="Bussiness To Bussiness">Bussiness To Bussiness</option>
                                                </select>
                                            </div>
                                        </div>
                                        </div>

                                </div>

                                <div className="row">

                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label>IGST : 00.00%</label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="Igst" value={formData.Igst} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-8">
                                            <label className="d-flex">Other Crg. <input name="OtherCrg_Per" style={{width:"40px"}} type="text" className="w-5" placeholder="0"/>% </label>
                                            </div>
                                            <div className="col-md-4">
                                                <input type="text" name="OtherCrg" value={formData.OtherCrg} onChange={handleChange} placeholder="0"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                        <div className="row">
                                            <div className="col-md-12">
                                            <label>GR Total  : </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-3">
                                    <div className="row">
                                            <div className="col-md-12">
                                            0
                                            </div>
                                        </div>
                                    </div>

                                </div>

                          </div>

                          <div className="row">
                            <div className="col-md-3">
                                <button className="btn btn-primary" onClick={handleSubmit}> Generete JobWork Invoice </button>
                            </div>
                          </div>

                        </div>

                        <div
                          className="tab-pane fade"
                          id="invdetail"
                          role="tabpanel"
                        >

                       <div className="table-responsive">
                                <table className="table table-bordered">
                                <thead>
                                    <tr>
                                    <th>Sr.</th>
                                    <th>PO No </th>
                                    <th>Item No Code</th>
                                    <th>Stock</th>
                                    <th>Description</th>
                                    <th>JobWork Rate</th>
                                    <th>PO Qty</th>
                                    <th>Bal.Qty</th>
                                    <th>Inv.Qty</th>
                                    <th>Pkg Qty</th>
                                    <th>Pkg.Desc</th>
                                    <th>Ref.</th>
                                    <th>Material Rate</th>
                                    <th>Del</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {tableData.map((item, index) => (
                                        <tr key={index}>
                                            <td>{index + 1}</td>
                                            <td><span className="fw-bold">PO No:</span> {item.po_no}</td>
                                            <td>{item.item_code}</td>
                                            <td></td>
                                            <td><textarea className="form-control" value={item.description} readOnly rows="2"></textarea> <span className="d-block mt-1" style={{fontSize: '12px', fontWeight: '500'}}>HSN Code :</span> </td>
                                            <td className="text-start">
                                                <input type="text" className="form-control form-control-sm mb-1" defaultValue={item.jobwork_rate} />
                                                <span style={{color:"blue", fontSize: '12px'}}>Rate Type: </span>
                                                <br /> 
                                                <select className="form-select form-select-sm" defaultValue={item.rate_type}>
                                                    <option value="NOS">NOS</option>
                                                </select>
                                            </td>
                                            <td>{item.po_qty}</td>
                                            <td>{item.bal_qty}</td>
                                            <td>
                                                <input type="text" className="form-control form-control-sm mb-1" defaultValue={item.inv_qty}/>
                                                <span className="d-block" style={{fontSize: '11px'}}>Per Pcs Wt:</span>
                                                <input type="text" className="form-control form-control-sm mb-1" placeholder="Weight" />
                                                <span style={{color:"blue", fontSize: '11px'}}>Per Unit: </span>
                                            </td>
                                            <td><input type="text" className="form-control form-control-sm" defaultValue={item.pkg_qty}/></td>
                                            <td><textarea className="form-control" defaultValue={item.pkg_desc} rows="2"></textarea></td>
                                            <td>{item.ref}</td>
                                            <td><input type="text" className="form-control form-control-sm" defaultValue={item.material_rate} /></td>
                                            <td className="text-center align-middle">
                                                <span 
                                                    className="badge bg-danger p-2 shadow-sm" 
                                                    style={{cursor: 'pointer'}} 
                                                    onClick={() => setTableData(tableData.filter((_, i) => i !== index))}
                                                    title="Remove Item"
                                                >
                                                    &times;
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                    {tableData.length === 0 && (
                                        <tr>
                                            <td colSpan="14" className="text-center py-5 text-muted">
                                                <h6>No Items Added</h6>
                                                <p className="mb-0" style={{fontSize: '14px'}}>Please add items from the "Item Details" tab.</p>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                                </table>
                      </div>
                       </div> 

                      </div>

                    </div>
                  </div>

                </div>
              </main>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


export default GSTJobworkInvoice